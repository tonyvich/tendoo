<div class="container-fluid">
     <div class="jumbotron">
          <h1><?php echo __( 'Thank You', 'nexo-updater' );?></h1>
          <p><?php echo __( 'Thank you for activating your copy of NexoPOS. You can now contact us to receive assistance or even to personalize the software if you want. Don\'t hesitate to disturb us.', 'nexo-updater' );?></p>
     </div>
</div>