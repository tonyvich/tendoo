<?php
$lang[ 'nexo-premium-unable-to-locate-backup' ]        =    tendoo_error(__('Impossible de retrouver le fichier de sauvegarde.', 'nexo_premium'));
$lang[ 'restore_successful' ]                        =    tendoo_success(__('La restauration s\'est déroulé correctement.', 'nexo_premium'));
$lang[ 'provider_account_cateogry_missing' ]           =    tendoo_info( __( 'Vous devez fournir une catégorie pour les dépenses relatives au paiement des fournisseurs.', 'nexo_premium' ) );
