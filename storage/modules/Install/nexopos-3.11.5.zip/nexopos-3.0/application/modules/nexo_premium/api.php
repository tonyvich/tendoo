<?php
$Routes->post( 'nexopos/cashiers_performance', 'NexoPremiumReportController@cashierPerformance' );