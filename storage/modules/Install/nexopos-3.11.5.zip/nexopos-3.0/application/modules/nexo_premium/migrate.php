<?php
return array(
    '2.7'			=>		MODULESPATH . '/nexo_premium/migrate/2.7.0.php',
	'2.2'			=>		MODULESPATH . '/nexo_premium/migrate/2.2.php',
    '2.0.3'        	=>		MODULESPATH . '/nexo_premium/migrate/2.0.3.php',
    '1.9'        	=>		MODULESPATH . '/nexo_premium/migrate/1.9.php'
);
