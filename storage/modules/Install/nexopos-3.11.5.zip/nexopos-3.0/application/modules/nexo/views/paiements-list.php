<?php
$this->Gui->col_width(1, 4);
// var_dump( $crud_content );die;
$this->Gui->add_meta(array(
    'namespace'    =>    'paiements',
    'type'        =>    'unwrapped',
    'col_id'    =>    1,
    'title'        =>    __('Gestion & Création des moyens de paiements', 'nexo')
));

$this->Gui->add_item(array(
    'type'        =>    'dom',
    'content'    =>    $crud_content->output
), 'paiements', 1);

$this->Gui->output();
