<?php
class NexoTaskController extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
}