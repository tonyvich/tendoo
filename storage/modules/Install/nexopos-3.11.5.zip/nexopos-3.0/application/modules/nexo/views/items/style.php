<style type="text/css">
.not-available {
    background: #808080;
    color: #FFF;
}
</style>