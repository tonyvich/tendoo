<div class="btn-group" role="group">
    <button type="button" class="btn btn-default btn-lg" id="cart-return-to-order"  style="margin-bottom:0px;"> <!-- btn-app  -->
    <i class="fa fa-refresh"></i>
        <span class="hidden-xs"><?php _e('Annuler', 'nexo');?></span>
    </button>
</div>