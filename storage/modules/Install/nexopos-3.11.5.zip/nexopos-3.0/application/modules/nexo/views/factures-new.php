<?php

$this->Gui->col_width(1, 3);


$this->Gui->output();
