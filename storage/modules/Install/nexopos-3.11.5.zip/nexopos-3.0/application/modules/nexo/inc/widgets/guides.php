<ul class="nav nav-stacked box-body" style="padding:0;">
  <li><a href="<?php echo site_url(array( 'dashboard', 'nexo', 'fournisseurs', 'add?guide=true' ));?>"><?php echo __('Ajouter un fournisseur', 'nexo');?> </a></li>
  <li><a href="<?php echo site_url(array( 'dashboard', 'nexo', 'rayons', 'add?guide=true' ));?>"><?php echo __('Ajouter un rayon', 'nexo');?> </a></li>
  <li><a href="<?php echo site_url(array( 'dashboard', 'nexo', 'categories', 'add?guide=true' ));?>"><?php echo __('Ajouter une catégorie', 'nexo');?> </a></li>
  <li><a href="<?php echo site_url(array( 'dashboard', 'nexo', 'arrivages', 'add?guide=true' ));?>"><?php echo __('Ajouter une collection', 'nexo');?> </a></li>
  <li><a href="<?php echo site_url(array( 'dashboard', 'nexo', 'produits', 'add?guide=true' ));?>"><?php echo __('Ajouter un article', 'nexo');?> </a></li>
  <li><a href="<?php echo site_url(array( 'dashboard', 'nexo', 'commandes', 'lists', 'add?guide=true' ));?>"><?php echo __('Effectuer une commande', 'nexo');?> </a></li>
</ul>