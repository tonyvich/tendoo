<div class="btn-group" role="group" ng-controller="payBox">
     <button type="button" class="btn btn-default btn-lg" ng-click="openPayBox()" style="margin-bottom:0px;"> <i class="fa fa-money"></i>
     <span class="hidden-xs"><?php _e('Payer', 'nexo');?></span>
     </button>
</div>