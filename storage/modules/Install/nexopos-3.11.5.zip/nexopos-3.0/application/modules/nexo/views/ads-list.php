<?php

$this->Gui->output();
