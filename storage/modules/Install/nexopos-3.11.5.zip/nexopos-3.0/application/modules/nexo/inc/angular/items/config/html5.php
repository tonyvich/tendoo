<script type="text/javascript">
"use strict";
tendooApp.config( function( $locationProvider ) {
    $locationProvider.html5Mode({
        enabled     :   true
    });
});
</script>
