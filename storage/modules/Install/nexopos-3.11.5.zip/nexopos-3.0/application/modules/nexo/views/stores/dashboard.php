<?php

$this->Gui->output();