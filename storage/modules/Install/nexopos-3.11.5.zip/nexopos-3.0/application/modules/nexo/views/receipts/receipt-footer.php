<?php if( @$_GET[ 'autoprint' ] == 'true' ):?>
<script>
window.print();
window.close();
</script>
<?php endif;?>