# You're using Tendoo CMS 3.1.4

##Functions
	- helpers
		"this_is" 
		@param string page slug [ 'migrate_page', 'dashboard_page', 'settings_page', 'modules_list_page', 'modules_install_page', 'users_list_page']
		@return bool

##Hooks
	- Actions
		"before_setting_tables" has changed for "before_db_setup"
		